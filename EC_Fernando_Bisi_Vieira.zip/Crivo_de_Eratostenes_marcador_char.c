#include <stdio.h>
#include <stdlib.h>
#include "Crivo_de_Eratostenes_marcador_char.h"

#define MARCADO 'm'
#define DESMARCADO 'd'

unsigned int* cria_lista(unsigned int final){
  unsigned int* lista_numeros = (unsigned int*)malloc(sizeof(char)*(final-1)); //lista de 2 a N
  for (unsigned int indice = 0; indice < final; indice++) {
    lista_numeros[indice] = DESMARCADO;
  }
  return lista_numeros;
}

void marca_multiplos(unsigned int numero, unsigned int final, unsigned int* lista){
  for (unsigned int numero_da_lista = numero+1; numero_da_lista <= final+1; numero_da_lista++) {
    if (numero_da_lista % numero == 0 ) {
      lista[numero_da_lista-2] = MARCADO;
    }
  }
}

unsigned int proximo_primo_na_lista(unsigned int primo_atual, unsigned int final, unsigned int* lista){
  for (unsigned int prox_primo = primo_atual+1; prox_primo <= final; prox_primo++) {
    if (lista[prox_primo-2] == DESMARCADO) {
      primo_atual = prox_primo;
      break;
    }
  }
  return primo_atual;
}

void imprime_primos_na_lista(unsigned int final, unsigned int* lista){
  printf("Primos menores ou iguais a N:\n");
  for (unsigned int i = 0; i < final; i++) {
    if (lista[i] == DESMARCADO) {
      printf("%d ",i+2);
    }
  }
  printf("\n");
}

// int main(int argc, char const *argv[]) {
//   unsigned int N = 1;
//   printf("Digite o número N para o qual se quer encontrar todos os primos menores ou iguais a N:\n");
//   scanf("%d",&N);
//   unsigned int* lista_numeros = (unsigned int*)malloc(sizeof(unsigned int)*(N-1)); //lista de 2 a N
//   for (unsigned int indice = 0; indice < N; indice++) {
//     lista_numeros[indice] = DESMARCADO;
//   }
//   unsigned int i = 2; // menor número primo
//   printf("Os números primos são:\n");
//   while (i<=N) {
//     printf("%d ", i);
//     for (unsigned int numero_da_lista = i+1; numero_da_lista <= N; numero_da_lista++) {
//       if (numero_da_lista % i == 0 ) {
//         lista_numeros[numero_da_lista-2] = MARCADO;
//       }
//     }
//     for (unsigned int prox_primo = i+1; prox_primo <= N; prox_primo++) {
//       if (lista_numeros[prox_primo-2] == DESMARCADO) {
//         i = prox_primo;
//         break;
//       }if (prox_primo == N) {
//         i = N;
//       }
//     }
//     if (i == N) {
//       break;
//     }
//   }
//   printf("\n");
//   return 0;
// }
